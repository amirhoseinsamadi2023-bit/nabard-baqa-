const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
app.use(express.static(path.join(__dirname, 'public')));
const W=1600,H=1000,MAX=10;
const players=new Map(), bullets=[];
let zone={x:800,y:500,r:650}, tick=0, startedAt=Date.now();
const rand=(a,b)=>Math.random()*(b-a)+a;
function snapshot(){return {players:[...players.values()].map(p=>({id:p.id,name:p.name,x:p.x,y:p.y,hp:p.hp,alive:p.alive,color:p.color,score:p.score})),bullets:bullets.map(b=>({x:b.x,y:b.y})),zone,tick,started:players.size>=2};}
io.on('connection',s=>{
 if(players.size>=MAX){s.emit('full');s.disconnect(true);return;}
 const p={id:s.id,name:'بازیکن '+(players.size+1),x:rand(180,1420),y:rand(150,850),hp:100,alive:true,color:['#43d9bd','#ffcb58','#ff6b6b','#7b9cff','#c18aff'][players.size%5],score:0,lastShot:0};
 players.set(s.id,p); s.emit('welcome',{id:s.id,world:{w:W,h:H},max:MAX}); io.emit('state',snapshot());
 s.on('name',n=>{if(typeof n==='string')p.name=n.trim().slice(0,16)||p.name;});
 s.on('move',d=>{if(!p.alive)return; const dx=Math.max(-1,Math.min(1,Number(d.x)||0)),dy=Math.max(-1,Math.min(1,Number(d.y)||0)); const len=Math.hypot(dx,dy)||1; p.x=Math.max(25,Math.min(W-25,p.x+dx/len*5));p.y=Math.max(25,Math.min(H-25,p.y+dy/len*5));});
 s.on('shoot',d=>{if(!p.alive||Date.now()-p.lastShot<280)return;p.lastShot=Date.now();const a=Number(d.angle);if(!Number.isFinite(a))return;bullets.push({x:p.x,y:p.y,vx:Math.cos(a)*12,vy:Math.sin(a)*12,owner:p.id,life:75});});
 s.on('disconnect',()=>{players.delete(s.id);io.emit('state',snapshot());});
});
setInterval(()=>{
 tick++; zone.r=Math.max(110,650-Math.max(0,Date.now()-startedAt-15000)/1000*3.2);
 for(let i=bullets.length-1;i>=0;i--){const b=bullets[i];b.x+=b.vx;b.y+=b.vy;b.life--;let hit=false;
  for(const p of players.values()){if(!p.alive||p.id===b.owner)continue;if(Math.hypot(p.x-b.x,p.y-b.y)<22){p.hp-=34;hit=true;if(p.hp<=0){p.hp=0;p.alive=false;const owner=players.get(b.owner);if(owner)owner.score++;}break;}}
  if(hit||b.life<=0||b.x<0||b.y<0||b.x>W||b.y>H)bullets.splice(i,1);
 }
 for(const p of players.values())if(p.alive&&Math.hypot(p.x-zone.x,p.y-zone.y)>zone.r){p.hp-=0.18;if(p.hp<=0){p.hp=0;p.alive=false;}}
 if(tick%2===0)io.emit('state',snapshot());
},50);
app.get('/health',(req,res)=>res.json({ok:true,players:players.size,max:MAX}));
const port=process.env.PORT||3000;server.listen(port,()=>console.log('نبرد بقا online server on '+port));
