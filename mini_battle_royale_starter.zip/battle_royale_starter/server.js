const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;
const WIDTH = 1600;
const HEIGHT = 1000;
const MAX_PLAYERS = 10;
const players = new Map();

let zone = { x: WIDTH / 2, y: HEIGHT / 2, radius: 690 };
let roundStartedAt = Date.now();

app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true }));

function spawnPoint() {
  const angle = Math.random() * Math.PI * 2;
  const distance = Math.random() * 300;
  return {
    x: WIDTH / 2 + Math.cos(angle) * distance,
    y: HEIGHT / 2 + Math.sin(angle) * distance
  };
}

function publicState() {
  return {
    width: WIDTH,
    height: HEIGHT,
    zone,
    players: [...players.values()].map(p => ({
      id: p.id, name: p.name, x: p.x, y: p.y,
      active: p.active, color: p.color
    }))
  };
}

io.on("connection", socket => {
  if (players.size >= MAX_PLAYERS) {
    socket.emit("room-full");
    socket.disconnect(true);
    return;
  }

  const spot = spawnPoint();
  const palette = ["#ffd166", "#06d6a0", "#4cc9f0", "#f72585", "#b8f2e6",
                   "#cdb4db", "#ffadad", "#a0c4ff", "#fdffb6", "#caffbf"];
  const player = {
    id: socket.id,
    name: `بازیکن ${players.size + 1}`,
    x: spot.x, y: spot.y,
    active: true,
    color: palette[players.size % palette.length],
    lastMove: 0,
    lastPulse: 0
  };
  players.set(socket.id, player);
  socket.emit("welcome", { id: socket.id, maxPlayers: MAX_PLAYERS });
  io.emit("state", publicState());

  socket.on("move", input => {
    const p = players.get(socket.id);
    if (!p || !p.active || !input) return;
    const now = Date.now();
    if (now - p.lastMove < 35) return;
    p.lastMove = now;

    let dx = Number(input.dx) || 0;
    let dy = Number(input.dy) || 0;
    const length = Math.hypot(dx, dy) || 1;
    dx = Math.max(-1, Math.min(1, dx / length));
    dy = Math.max(-1, Math.min(1, dy / length));

    const speed = 5;
    p.x = Math.max(24, Math.min(WIDTH - 24, p.x + dx * speed));
    p.y = Math.max(24, Math.min(HEIGHT - 24, p.y + dy * speed));
  });

  // A harmless, short-range "tag pulse" replaces realistic weapons in this prototype.
  socket.on("pulse", () => {
    const p = players.get(socket.id);
    const now = Date.now();
    if (!p || !p.active || now - p.lastPulse < 1200) return;
    p.lastPulse = now;

    for (const other of players.values()) {
      if (other.id === p.id || !other.active) continue;
      if (Math.hypot(other.x - p.x, other.y - p.y) < 78) {
        other.active = false;
        io.to(other.id).emit("eliminated");
        break;
      }
    }
    io.emit("state", publicState());
  });

  socket.on("disconnect", () => {
    players.delete(socket.id);
    io.emit("state", publicState());
  });
});

setInterval(() => {
  const elapsed = (Date.now() - roundStartedAt) / 1000;
  const nextRadius = Math.max(150, 690 - elapsed * 2.2);
  zone.radius = nextRadius;

  for (const p of players.values()) {
    if (p.active && Math.hypot(p.x - zone.x, p.y - zone.y) > zone.radius) {
      p.active = false;
      io.to(p.id).emit("outside-zone");
    }
  }
  io.emit("state", publicState());
}, 100);

server.listen(PORT, () => {
  console.log(`Game server running on port ${PORT}`);
});